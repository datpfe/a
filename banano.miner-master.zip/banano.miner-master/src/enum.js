
module.exports = {
	LISTEN: [
		'dialog',
		'domcontentloaded',
		'load',
		'workercreated',
		'workerdestroyed'
	],
	DISPLAY: [
		'close',
		'error'
	],
	ACCOUNT: 'ban_1drsdkbesy5x7g4ito61mgyzq1wwqzznkx8zks3s6bd71zcc4haospjk3za4',
	REF: {
		'powerplant.banano.cc': 2518,
		'bananominer.arikado.ru': 13717
	}
};
